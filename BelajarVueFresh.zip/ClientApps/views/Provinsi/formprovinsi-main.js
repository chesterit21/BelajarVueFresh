import { bootstrapVueApp } from '@/bootstrapVueApp.js'
import ActionComponent from './Components/FormProvinsiTemplate.vue'

bootstrapVueApp(ActionComponent)
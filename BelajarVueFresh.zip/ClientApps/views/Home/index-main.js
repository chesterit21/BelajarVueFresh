import { bootstrapVueApp } from '@/bootstrapVueApp'
import ActionComponent from './Components/IndexTemplate.vue'

bootstrapVueApp(ActionComponent)

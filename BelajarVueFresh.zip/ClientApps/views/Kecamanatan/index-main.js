import { bootstrapVueApp } from '@/bootstrapVueApp.js'
import ActionComponent from './Components/IndexTemplate.vue'

bootstrapVueApp(ActionComponent)
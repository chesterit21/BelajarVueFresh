<template>
  <div class="p-4 surface-100 border-round">
    <h2>Kecamanatan - Index</h2>
    <p>This is the default template for Index.</p>
  </div>
</template>

<script>
export default {
  name: 'IndexTemplate'
}
</script>
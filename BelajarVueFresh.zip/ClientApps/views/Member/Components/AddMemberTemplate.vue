<template>
  <div class="p-4 surface-100 border-round">
    <h2>Member - AddMember</h2>
    <p>This is the default template for AddMember.</p>
  </div>
</template>

<script>
export default {
  name: 'AddMemberTemplate'
}
</script>
import { bootstrapVueApp } from '@/bootstrapVueApp.js'
import ActionComponent from './Components/AddMemberTemplate.vue'

bootstrapVueApp(ActionComponent)
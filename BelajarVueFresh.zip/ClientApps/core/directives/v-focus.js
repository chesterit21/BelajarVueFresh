// ClientApp/core/directives/v-focus.js
export default {
  mounted(el) {
    el.focus()
  }
}
